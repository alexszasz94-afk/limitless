/* Gentle falling snow over every page. Off for visitors who ask for reduced motion. */
(function () {
  var el = document.currentScript;
  var count = parseInt((el && el.getAttribute('data-flakes')) || '60', 10);
  if (!count || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var c = document.createElement('canvas');
  c.className = 'st-snow';
  c.setAttribute('aria-hidden', 'true');
  c.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:2147483000';
  document.body.appendChild(c);
  var ctx = c.getContext('2d'), w, h, dpr, flakes = [];
  function size() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth; h = window.innerHeight;
    c.width = w * dpr; c.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function flake(top) {
    return { x: Math.random() * w, y: top ? -10 : Math.random() * h, r: 1 + Math.random() * 2.6,
      s: 0.4 + Math.random() * 1.1, d: Math.random() * Math.PI * 2, o: 0.55 + Math.random() * 0.4 };
  }
  size();
  if (w < 600) count = Math.round(count * 0.6);
  for (var i = 0; i < count; i++) flakes.push(flake(false));
  window.addEventListener('resize', size);
  var last = 0;
  function tick(t) {
    var dt = Math.min((t - last) / 16.7 || 1, 3); last = t;
    ctx.clearRect(0, 0, w, h);
    for (var i = 0; i < flakes.length; i++) {
      var f = flakes[i];
      f.d += 0.01 * dt; f.y += f.s * dt; f.x += Math.sin(f.d) * 0.4 * dt;
      if (f.y > h + 5) flakes[i] = f = flake(true);
      ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, 6.2832);
      ctx.fillStyle = 'rgba(255,255,255,' + f.o + ')';
      ctx.shadowColor = 'rgba(90,120,160,.55)'; ctx.shadowBlur = 3; ctx.fill();
      ctx.lineWidth = 0.6; ctx.strokeStyle = 'rgba(150,175,205,' + (f.o * 0.7) + ')'; ctx.stroke();
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})();
