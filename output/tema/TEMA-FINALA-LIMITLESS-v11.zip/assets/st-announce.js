/* Store announcement bar: real Christmas / date / restarting countdown + rotating messages. */
(function () {
  function pad(n) { return n < 10 ? '0' + n : String(n); }
  function parseEnd(v) {
    if (!v) return null;
    var s = String(v).trim().replace(' ', 'T');
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) s += 'T23:59:59';
    var t = new Date(s).getTime();
    return isNaN(t) ? null : t;
  }
  function initCount(wrap) {
    var mode = wrap.getAttribute('data-mode');
    var live = wrap.querySelector('[data-st-live]');
    var done = wrap.querySelector('[data-st-done]');
    var cycle = Math.max(parseInt(wrap.getAttribute('data-minutes'), 10) || 30, 1) * 60000;
    var key = 'stCountdown';
    var end;
    function newCycle() {
      var next = Date.now() + cycle;
      try { localStorage.setItem(key, String(next)); } catch (e) { /* storage blocked */ }
      return next;
    }
    if (mode === 'christmas') {
      // Midnight starting 25 December, visitor's own time zone.
      end = new Date(new Date().getFullYear(), 11, 25).getTime();
    } else if (mode === 'date') {
      end = parseEnd(wrap.getAttribute('data-end'));
    } else {
      var saved = null;
      try { saved = parseInt(localStorage.getItem(key), 10); } catch (e) { /* storage blocked */ }
      end = saved && saved > Date.now() && saved - Date.now() <= cycle ? saved : newCycle();
    }
    var units = {};
    ['d', 'h', 'm', 's'].forEach(function (u) {
      var el = wrap.querySelector('[data-unit="' + u + '"]');
      units[u] = el && el.tagName === 'B' ? el : el && el.querySelector('b');
    });
    var dayTile = wrap.querySelector('.st-ann__tile[data-unit="d"]');
    var timer;
    function finish() {
      clearInterval(timer);
      live.hidden = true;
      if (done.textContent.trim()) { done.hidden = false; } else { wrap.hidden = true; }
    }
    function set(el, v) {
      if (el.textContent === v) return;
      el.textContent = v;
      el.classList.remove('is-tick');
      void el.offsetWidth;
      el.classList.add('is-tick');
    }
    function tick() {
      var left = end - Date.now();
      if (left <= 0) {
        if (mode !== 'evergreen') return finish();
        end = newCycle();
        left = end - Date.now();
      }
      var s = Math.floor(left / 1000);
      var d = Math.floor(s / 86400); s -= d * 86400;
      var h = Math.floor(s / 3600); s -= h * 3600;
      var m = Math.floor(s / 60); s -= m * 60;
      dayTile.hidden = d === 0;
      set(units.d, String(d));
      set(units.h, pad(h));
      set(units.m, pad(m));
      set(units.s, pad(s));
    }
    if (!end || end <= Date.now() && mode !== 'evergreen') return finish();
    live.hidden = false;
    tick();
    timer = setInterval(tick, 1000);
  }
  function initMsgs(bar) {
    var msgs = bar.querySelectorAll('.st-ann__msg');
    if (msgs.length < 2) return;
    var i = 0;
    setInterval(function () {
      msgs[i].classList.remove('is-on');
      msgs[i].classList.add('is-out');
      var old = msgs[i];
      setTimeout(function () { old.classList.remove('is-out'); }, 600);
      i = (i + 1) % msgs.length;
      msgs[i].classList.add('is-on');
    }, 3800);
  }
  function init() {
    document.querySelectorAll('[data-st-count]').forEach(initCount);
    document.querySelectorAll('[data-st-msgs]').forEach(initMsgs);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
