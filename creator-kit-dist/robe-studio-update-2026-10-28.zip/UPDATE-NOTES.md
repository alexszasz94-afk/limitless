# Robe Studio update 2026-10-28

- Videos now come WITHOUT on-screen text: Claude tells you the exact text (words + emojis) under each video and in text.txt; you add it in CapCut at the top of the screen.
- After every video Claude offers 2 more hooks on the same B-roll (cheaper and faster) and a new cozy ending if you want.
- Connector and remote are now ready-made 4K close-ups by the Christmas tree, used in rotation (never generated).
- Music: Christmas songs for Snoopy too; the music is quiet under the hook and goes louder on the beat drop at the cut.
- Images are made with GPT Image 2.5 only (spells logos right). New Snoopy display box (camel, HEATPUP).
- Rooms: real phone photos only, never AI. Rooms now come in zips from Alex: drag the zip into the chat and say 'add these rooms'.
- Snoopy B-roll uses the locked recipe that worked on every video. Second B-roll movement for Princess (alternates automatically).

## For Claude — do this once, right after installing this update
1. Move the old AI-looking rooms out of the pool: for every file library/rooms/room-01.jpg … room-13.jpg that exists, run python3 engine/tools.py reject <file>.
2. Run step 3 of the skill setup: it uploads only the new files that have no id yet in state/media.json (snoopy_box_display, motion2). Never upload anything twice.
3. Commit and push, then tell the creator in 2-3 simple lines what is new, and that they should drag in the rooms zip from Alex (rooms-2026-10-28.zip) and say 'add these rooms'.
