# Robe Studio — start here

**This setup is only for Claude Code on the web (claude.ai/code).** Everything runs in your browser. Nothing to install, no experience needed. The step-by-step page with every click explained is **SETUP.html**.

**You never edit anything** — no video editing, no files, no code. You send a reel or an idea; Claude makes, checks and edits the whole video and gives you the finished MP4.

**Who does what**
- **Alex** prepares the kit and sends you: this guide and a folder **robe-studio-upload** with 5 files (the whole kit). About once a week he sends a small update file.
- **You** make the accounts (Claude Pro, Higgsfield, free GitHub), click the 5 steps below once, then just send Claude reels and ideas and post the videos.

**Once (about 5 minutes)**
1. On **github.com** (free account): **+** → **New repository** → name `robe-studio` → **Private** → **Create repository** → click **uploading an existing file** → drag the 5 files from Alex's folder → **Commit changes**.
2. Go to **claude.ai/customize/connectors** → **Higgsfield** → **Connect** → log in to Higgsfield.
3. Go to **claude.ai/code** → connect GitHub if asked → pick your `robe-studio` repository.
4. Click the environment name at the top → **Edit** → **Network access** → either **Full** (easiest) or **Custom/Limited** with the list from `setup/allowed-domains.txt` pasted in **Allowed domains** (stricter) → **Save**.
5. Write **"Hi, set me up"**. Claude does the rest and tells you when it's ready.

**Every day**
Just talk to Claude like to a person:
- "Make this one with the princess robe: <reel link>"
- "I have an idea: she opens the door and her mom is holding a giant gift box…"
- "The text is too big" · "Use another song" · "How many videos can I still make?"

Want a specific song? Drag the MP3 into the chat and say "use this song" — Claude puts it in perfectly.

**Updates:** when Alex sends `robe-studio-update-<date>.zip`, drag it into a chat and write "here is the new update from Alex". Claude installs it.

Claude asks you which cozy ending you want, makes the video, checks it and gives you the MP4 + a caption. Your part is the ideas: copy reels that work, and invent your own hooks.
