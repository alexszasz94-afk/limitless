/* =====================================================================
   LP Landing — shared behaviour for the brand landing pages.
   Countdown, rotating bar, gallery, bundle offers, add to cart,
   sticky bar, sliders and scroll reveal. Safe to load more than once.
   ===================================================================== */
(function () {
  'use strict';
  if (window.__lpLanding) return;
  window.__lpLanding = true;
  document.documentElement.classList.add('lp-js');

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  function once(el, key) {
    var flag = 'lpBound' + key;
    if (el.dataset[flag]) return false;
    el.dataset[flag] = '1';
    return true;
  }

  /* ---------- Money ---------- */
  function formatMoney(cents, format) {
    format = String(format || '${{amount}}').replace(/<[^>]*>/g, '');
    var match = format.match(/\{\{\s*(\w+)\s*\}\}/);
    function delimit(number, precision, thousands, decimal) {
      var fixed = (number / 100).toFixed(precision);
      var parts = fixed.split('.');
      var whole = parts[0].replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1' + thousands);
      return whole + (parts[1] ? decimal + parts[1] : '');
    }
    var value;
    switch (match ? match[1] : 'amount') {
      case 'amount_no_decimals': value = delimit(cents, 0, ',', '.'); break;
      case 'amount_with_comma_separator': value = delimit(cents, 2, '.', ','); break;
      case 'amount_no_decimals_with_comma_separator': value = delimit(cents, 0, '.', ','); break;
      case 'amount_with_apostrophe_separator': value = delimit(cents, 2, "'", '.'); break;
      case 'amount_no_decimals_with_space_separator': value = delimit(cents, 0, ' ', ','); break;
      case 'amount_with_space_separator': value = delimit(cents, 2, ' ', ','); break;
      case 'amount_with_period_and_space_separator': value = delimit(cents, 2, ' ', '.'); break;
      default: value = delimit(cents, 2, ',', '.');
    }
    return format.replace(/\{\{\s*\w+\s*\}\}/, value);
  }

  /* ---------- Toast ---------- */
  var toastEl;
  function toast(message) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'lp-toast';
      toastEl.setAttribute('role', 'status');
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = message;
    toastEl.classList.add('is-visible');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(function () { toastEl.classList.remove('is-visible'); }, 3600);
  }

  /* ---------- Countdown: restarting per-visitor timer, or a fixed end date ---------- */
  function parseEnd(value) {
    if (!value) return null;
    var s = String(value).trim().replace(' ', 'T');
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) s += 'T23:59:59';
    var t = new Date(s).getTime();
    return isNaN(t) ? null : t;
  }
  function pad(n) { return n < 10 ? '0' + n : String(n); }

  function initCountdowns(scope) {
    $$('[data-lp-countdown]', scope).forEach(function (wrap) {
      if (!once(wrap, 'Countdown')) return;
      var live = $('[data-lp-countdown-live]', wrap);
      var fallback = $('[data-lp-countdown-fallback]', wrap);
      var time = $('[data-lp-countdown-time]', wrap);
      var timer = null;
      var evergreen = wrap.getAttribute('data-mode') === 'evergreen';
      var cycle = Math.max(parseInt(wrap.getAttribute('data-minutes'), 10) || 30, 1) * 60000;
      var storeKey = 'lpCountdown:' + location.pathname;

      // Restarting timer: remembered per visitor, starts a new cycle when it hits zero.
      function newCycle() {
        var next = Date.now() + cycle;
        try { localStorage.setItem(storeKey, String(next)); } catch (err) { /* storage blocked */ }
        return next;
      }
      function savedEnd() {
        var saved = null;
        try { saved = parseInt(localStorage.getItem(storeKey), 10); } catch (err) { /* storage blocked */ }
        return saved && saved > Date.now() && saved - Date.now() <= cycle ? saved : newCycle();
      }

      var end = evergreen ? savedEnd() : parseEnd(wrap.getAttribute('data-end'));
      function finish() {
        if (timer) clearInterval(timer);
        if (live) live.hidden = true;
        if (fallback) fallback.hidden = false;
      }
      if (!time || (!evergreen && (!end || end <= Date.now()))) return finish();
      if (live) live.hidden = false;
      if (fallback) fallback.hidden = true;
      function tick() {
        if (!document.body.contains(wrap)) return clearInterval(timer);
        var left = end - Date.now();
        if (left <= 0) {
          if (!evergreen) return finish();
          end = newCycle();
          left = end - Date.now();
        }
        var s = Math.floor(left / 1000);
        var d = Math.floor(s / 86400); s -= d * 86400;
        var h = Math.floor(s / 3600); s -= h * 3600;
        var m = Math.floor(s / 60); s -= m * 60;
        time.textContent = (d > 0 ? d + 'D ' : '') + pad(h) + ':' + pad(m) + ':' + pad(s);
      }
      timer = setInterval(tick, 1000);
      tick();
    });
  }

  /* ---------- Rotating announcement bar ---------- */
  function initRotators(scope) {
    $$('[data-lp-rotator]', scope).forEach(function (bar) {
      if (!once(bar, 'Rotator')) return;
      var msgs = $$('.lp-bar__msg', bar);
      if (msgs.length < 2) return;
      var i = 0;
      setInterval(function () {
        msgs[i].classList.remove('is-active');
        i = (i + 1) % msgs.length;
        msgs[i].classList.add('is-active');
      }, 4200);
    });
  }

  /* ---------- Product gallery ----------
     The slides sit in a horizontal scroll-snap track, so phones get a native
     finger swipe; arrows, thumbnails and the counter all follow the track. */
  function initGallery(root) {
    var track = $('[data-lp-gallery-track]', root);
    var slides = $$('[data-lp-slide]', root);
    var thumbs = $$('[data-lp-thumb]', root);
    var counter = $('[data-lp-gallery-count]', root);
    if (!track || !slides.length) return null;
    var index = 0;

    function setActive(i) {
      index = i;
      thumbs.forEach(function (thumb, n) {
        thumb.classList.toggle('is-active', n === i);
        thumb.setAttribute('aria-current', n === i ? 'true' : 'false');
      });
      slides.forEach(function (slide, n) {
        var video = slide.querySelector('video');
        if (video && n !== i && !video.paused) video.pause();
      });
      if (counter) counter.textContent = (i + 1) + ' / ' + slides.length;
      var active = thumbs[i];
      if (active) {
        var strip = active.parentNode;
        strip.scrollTo({ left: active.offsetLeft - strip.clientWidth / 2 + active.clientWidth / 2, behavior: 'smooth' });
      }
    }

    function go(i, instant) {
      i = (i + slides.length) % slides.length;
      track.scrollTo({ left: i * track.clientWidth, behavior: instant ? 'auto' : 'smooth' });
      setActive(i);
    }

    // Follow finger swipes / trackpad scrolling once the track settles.
    var settle = null;
    track.addEventListener('scroll', function () {
      clearTimeout(settle);
      settle = setTimeout(function () {
        var i = Math.round(track.scrollLeft / Math.max(track.clientWidth, 1));
        if (i !== index && i >= 0 && i < slides.length) setActive(i);
      }, 90);
    }, { passive: true });

    thumbs.forEach(function (thumb, n) { thumb.addEventListener('click', function () { go(n); }); });
    var prev = $('[data-lp-gallery-prev]', root);
    var next = $('[data-lp-gallery-next]', root);
    if (prev) prev.addEventListener('click', function () { go(index - 1); });
    if (next) next.addEventListener('click', function () { go(index + 1); });

    // Keep the current photo in place when the screen is rotated / resized.
    window.addEventListener('resize', function () { go(index, true); });
    setActive(0);

    return {
      goToMedia: function (mediaId) {
        slides.forEach(function (slide, n) {
          if (String(slide.getAttribute('data-media-id')) === String(mediaId)) go(n);
        });
      }
    };
  }

  /* ---------- Buy box: offers, variants, add to cart, sticky bar ---------- */
  function initBuybox(root) {
    if (!once(root, 'Buybox')) return;
    // Remember this landing page: home / catalog / cart links bring the visitor back here,
    // never to another product (see sections/lp-redirect.liquid).
    if (root.getAttribute('data-lp-remember') === 'true') {
      try { localStorage.setItem('lpLastLanding', window.location.pathname); } catch (err) { /* storage blocked */ }
    }
    var dataEl = $('[data-lp-product-json]', root);
    if (!dataEl) return;
    var data;
    try { data = JSON.parse(dataEl.textContent); } catch (err) { return; }

    var fmt = function (cents) { return formatMoney(cents, data.moneyFormat); };
    var gallery = initGallery(root);
    var form = $('[data-lp-form]', root);
    var atc = $('[data-lp-atc]', root);
    var atcLabel = $('[data-lp-atc-label]', root);
    var variantInput = $('[data-lp-variant-input]', root);
    var qtyInput = $('[data-lp-qty-input]', root);
    var offers = $$('[data-lp-offer]', root);
    var addonBoxes = $$('[data-lp-addon]', root);
    var addons = data.addons || {};
    var addonOn = {};
    Object.keys(addons).forEach(function (k) { addonOn[k] = !!addons[k].on; });
    var modal = $('[data-lp-modal]', root);
    var sticky = $('[data-lp-sticky]', root);
    var stickyBtn = sticky ? $('[data-lp-sticky-atc]', sticky) : null;
    if (!form || !variantInput) return;

    var variant = data.variants.filter(function (v) { return String(v.id) === variantInput.value; })[0] || data.variants[0];

    function selectedOffer() {
      return offers.filter(function (o) { return o.classList.contains('is-selected'); })[0] || offers[0] || null;
    }
    function offerQty(o) { return o ? Math.max(parseInt(o.getAttribute('data-qty'), 10) || 1, 1) : 1; }
    function offerPct(o) { return o ? Math.min(Math.max(parseFloat(o.getAttribute('data-pct')) || 0, 0), 95) : 0; }
    function unitCompare() { return Math.max(variant.compare || 0, variant.price); }
    function offerTotal(o) { return Math.round(variant.price * offerQty(o) * (100 - offerPct(o)) / 100); }
    function setAll(selector, fn) { $$(selector, root).forEach(fn); }

    function render() {
      offers.forEach(function (o) {
        var total = offerTotal(o);
        var was = unitCompare() * offerQty(o);
        var priceEl = $('[data-lp-offer-price]', o);
        var wasEl = $('[data-lp-offer-compare]', o);
        if (priceEl) priceEl.textContent = fmt(total);
        if (wasEl) { wasEl.textContent = was > total ? fmt(was) : ''; wasEl.hidden = !(was > total); }
      });

      var compare = variant.compare > variant.price ? variant.compare : 0;
      var savePct = compare ? Math.round((compare - variant.price) * 100 / compare) : 0;
      setAll('[data-lp-price]', function (el) { el.textContent = fmt(variant.price); });
      setAll('[data-lp-compare]', function (el) { el.textContent = compare ? fmt(compare) : ''; el.hidden = !compare; });
      setAll('[data-lp-save]', function (el) {
        el.textContent = String(data.saveLabel || 'SAVE {p}%').replace('{p}', savePct);
        el.hidden = !compare;
      });

      var offer = selectedOffer();
      var total = offerTotal(offer);
      var totalWas = unitCompare() * offerQty(offer);
      setAll('[data-lp-sticky-price]', function (el) { el.textContent = fmt(total); });
      setAll('[data-lp-sticky-compare]', function (el) { el.textContent = totalWas > total ? fmt(totalWas) : ''; el.hidden = !(totalWas > total); });

      qtyInput.value = offerQty(offer);
      variantInput.value = variant.id;
      var label = variant.available ? data.atcText : data.soldOutText;
      if (atc) atc.disabled = !variant.available;
      if (atcLabel) atcLabel.textContent = label;
      if (stickyBtn) { stickyBtn.disabled = !variant.available; stickyBtn.textContent = variant.available ? data.stickyText : data.soldOutText; }
    }

    // One state per add-on (shipping protection, express shipping);
    // only the selected offer shows its tick boxes.
    function syncAddons() {
      addonBoxes.forEach(function (box) {
        var active = box.closest('[data-lp-offer]').classList.contains('is-selected');
        box.checked = !!addonOn[box.getAttribute('data-lp-addon')];
        box.tabIndex = active ? 0 : -1;
      });
    }

    function selectOffer(o) {
      offers.forEach(function (x) {
        x.classList.toggle('is-selected', x === o);
        var r = $('input[type="radio"]', x);
        if (r) r.checked = x === o;
      });
      syncAddons();
      render();
    }

    offers.forEach(function (o) {
      // Clicking anywhere on a card selects it; on a not-selected card the
      // add-on row only selects the offer, it doesn't tick the box.
      o.addEventListener('click', function (e) {
        if (o.classList.contains('is-selected')) return;
        if (e.target.closest('.lp-offer__addon')) e.preventDefault();
        selectOffer(o);
      });
      var radio = $('input[type="radio"]', o);
      if (radio) radio.addEventListener('change', function () { selectOffer(o); });
    });

    addonBoxes.forEach(function (box) {
      box.addEventListener('change', function () {
        addonOn[box.getAttribute('data-lp-addon')] = box.checked;
        syncAddons();
      });
    });
    syncAddons();

    $$('[data-lp-variant]', root).forEach(function (btn) {
      btn.addEventListener('click', function () {
        var v = data.variants.filter(function (x) { return String(x.id) === btn.getAttribute('data-lp-variant'); })[0];
        if (!v) return;
        variant = v;
        $$('[data-lp-variant]', root).forEach(function (x) { x.classList.toggle('is-active', x === btn); });
        if (gallery && v.media) gallery.goToMedia(v.media);
        render();
      });
    });

    function setLoading(on) {
      [atc, stickyBtn].forEach(function (b) { if (b) b.classList.toggle('is-loading', on); });
    }
    // Coming back from checkout with the browser's Back button restores the page as it was.
    window.addEventListener('pageshow', function () { setLoading(false); });

    function postJSON(path, body) {
      return fetch(data.root + path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(body || {})
      }).then(function (res) {
        return res.json().then(function (json) {
          if (!res.ok) throw new Error(json.description || json.message || 'Could not add to cart');
          return json;
        });
      });
    }

    function addToCart() {
      if (!variant.available) return;
      var qty = offerQty(selectedOffer());
      var main = { id: variant.id, quantity: qty };
      // "Delivery: up to 4 weeks" travels with the product and shows in checkout.
      if (data.deliveryProperty) {
        main.properties = {};
        main.properties[data.deliveryProperty.name] = data.deliveryProperty.value;
      }
      // Offers like Order Three include the add-ons for free: they are not charged,
      // the checkout shows "Included: FREE Express Shipping + Shipping Protection" instead.
      var chosen = selectedOffer();
      var freeAddons = !!chosen && chosen.getAttribute('data-free-addons') === 'true';
      if (freeAddons && data.freeAddons) {
        main.properties = main.properties || {};
        main.properties[data.freeAddons.name] = data.freeAddons.value;
      }
      var items = [main];
      Object.keys(addons).forEach(function (k) {
        if (!freeAddons && addonOn[k] && addons[k].id) items.push({ id: addons[k].id, quantity: 1 });
      });

      // Outside Shopify (local preview) there is no real checkout: open the
      // checkout preview page next to this file with the same order.
      if (!window.Shopify || !window.fetch) {
        var offer = selectedOffer();
        var titleEl = offer ? $('.lp-offer__title', offer) : null;
        var firstImg = $('[data-lp-slide] img', root);
        var order = {
          shop: data.shopName, title: data.title, qty: qty, unit: variant.price, compare: unitCompare(),
          pct: offerPct(offer), discount: offerPct(offer) > 0 && titleEl ? titleEl.textContent.trim().toUpperCase() : '',
          properties: main.properties || {}, moneyFormat: data.moneyFormat, back: window.location.href,
          image: firstImg ? firstImg.src : '',
          addons: Object.keys(addons).filter(function (k) { return !freeAddons && addonOn[k] && addons[k].id; })
            .map(function (k) { return { label: addons[k].label, price: addons[k].price }; })
        };
        window.location.href = 'checkout.html#' + encodeURIComponent(JSON.stringify(order));
        return;
      }

      setLoading(true);
      var fail = function (err) { toast(err.message); setLoading(false); };

      // Straight to checkout (like snuglore): the cart is emptied first so checkout
      // holds exactly this order; automatic bundle discounts are applied there.
      if (data.afterAdd === 'checkout') {
        postJSON('cart/clear.js')
          .then(function () { return postJSON('cart/add.js', { items: items }); })
          .then(function () { window.location.href = data.root + 'checkout'; })
          .catch(fail);
        return;
      }
      postJSON('cart/add.js', { items: items })
        .then(function () { window.location.href = data.cartUrl; })
        .catch(fail);
    }

    // Delivery-time notice: shown when "Add to cart" is pressed, before checkout.
    var lastFocus = null;
    function closeModal() {
      if (!modal || modal.hidden) return;
      modal.hidden = true;
      document.documentElement.classList.remove('lp-modal-open');
      if (lastFocus) lastFocus.focus();
    }
    function buy(trigger) {
      if (!variant.available) return;
      if (!modal || !data.popup) return addToCart();
      lastFocus = trigger || atc;
      modal.hidden = false;
      document.documentElement.classList.add('lp-modal-open');
      var confirmBtn = $('[data-lp-modal-confirm]', modal);
      if (confirmBtn) confirmBtn.focus();
    }
    if (modal) {
      $$('[data-lp-modal-close]', modal).forEach(function (el) { el.addEventListener('click', closeModal); });
      var confirmBtn = $('[data-lp-modal-confirm]', modal);
      if (confirmBtn) confirmBtn.addEventListener('click', function () { lastFocus = null; closeModal(); addToCart(); });
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
    }

    form.addEventListener('submit', function (e) { e.preventDefault(); buy(atc); });
    if (stickyBtn) stickyBtn.addEventListener('click', function () { buy(stickyBtn); });

    if (sticky && 'IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        var entry = entries[0];
        sticky.classList.toggle('is-visible', !entry.isIntersecting && entry.boundingClientRect.top < 0);
      }).observe(form);
    }

    render();
  }

  /* ---------- Horizontal sliders ---------- */
  function initScrollers(scope) {
    $$('[data-lp-scroller]', scope).forEach(function (scroller) {
      if (!once(scroller, 'Scroller')) return;
      var track = $('[data-lp-scroller-track]', scroller);
      if (!track) return;
      function step() { return Math.max(track.clientWidth * 0.8, 220); }
      // Hide the floating arrows when everything already fits.
      var floating = $$('.lp-arrow', scroller).filter(function (b) { return !b.closest('.lp-scroller__nav'); });
      var nav = $('.lp-scroller__nav', scroller);
      function syncArrows() {
        var overflow = track.scrollWidth > track.clientWidth + 4;
        floating.forEach(function (b) { b.hidden = !overflow; });
        if (nav) nav.hidden = !overflow;
      }
      syncArrows();
      window.addEventListener('resize', syncArrows);
      $$('[data-lp-prev]', scroller).forEach(function (b) {
        b.addEventListener('click', function () { track.scrollBy({ left: -step(), behavior: 'smooth' }); });
      });
      $$('[data-lp-next]', scroller).forEach(function (b) {
        b.addEventListener('click', function () { track.scrollBy({ left: step(), behavior: 'smooth' }); });
      });
    });
  }

  /* ---------- Scroll reveal ---------- */
  var revealObserver = null;
  function initReveal(scope) {
    var els = $$('.lp-reveal:not(.is-in)', scope);
    var designMode = window.Shopify && window.Shopify.designMode;
    if (!('IntersectionObserver' in window) || designMode) {
      els.forEach(function (el) { el.classList.add('is-in'); });
      return;
    }
    if (!revealObserver) {
      revealObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('is-in');
          revealObserver.unobserve(entry.target);
        });
      }, { rootMargin: '0px 0px -8% 0px' });
    }
    els.forEach(function (el) { revealObserver.observe(el); });
  }

  function initAll(scope) {
    initCountdowns(scope);
    initRotators(scope);
    $$('[data-lp-buybox]', scope).forEach(initBuybox);
    initScrollers(scope);
    initReveal(scope);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { initAll(document); });
  } else {
    initAll(document);
  }
  // Re-init when a section is edited in the Shopify theme editor.
  document.addEventListener('shopify:section:load', function (e) { initAll(e.target); });
})();
