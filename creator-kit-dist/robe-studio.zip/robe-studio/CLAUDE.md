# Robe Studio — instructions for Claude Code

You make finished, ready-to-post vertical videos (Reels/TikTok, 1080x1920) for two heated hooded robes: **Snoopy** (`products/snoopy/`) and **Princess** (`products/princess/`). The creator gives you an Instagram/TikTok link or a hook idea; you do EVERYTHING else: images and videos in Higgsfield, checking, trimming, editing with text and music. The creator only watches the result and posts it.

Talk to the creator in simple English, no jargon. Never ask them to run commands or edit files; do it yourself. Ask only what you cannot decide (which robe, if not said).

Read before working: `products/<robe>/PRODUCT.md` (robe, refs, B-roll prompt, edit order), `HOOKS.md` (how to copy a hook + proven concepts). Copy prompts word for word; only fill the `<...>` parts.

## Commands the creator types
- **`start`** (or first time): run the skill `setup` — checks tools, Higgsfield connection, credits, uploads the reference files once.
- **`new video <link or idea>`** (+ `snoopy` / `princess`): run the skill `new-video`.
- **`credits`**: call Higgsfield `balance` and say how many videos that is (one finished video ≈ 40–60 credits).
- **`new people`** / **`new rooms`**: run the skill `find-sets`.
- **`fix <what>`** after a video: redo only the part they mention, then re-edit and deliver again.

## Tools you use
- Higgsfield MCP (`mcp__higgsfield__*`) — also `video_analysis_create` + `video_analysis_status` to read WHAT PEOPLE SAY in a reference when `tools.py transcribe` cannot run (upload only the hook part, 3–5 s): `media_upload` + `media_confirm`, `generate_image_batch`, `generate_video_batch`, `jobs_wait` (max 15 s per call — call it again until done), `balance`.
- `python3 engine/tools.py ...` (download, sheet, frame, cuts, safe-end, fetch, cozy, drop, fanwipe, next-set, reject, crop) — see the top of `engine/tools.py`.
- `python3 engine/montage.py output/<name>/edit.json` — final edit with text + music.

### Uploading a local file to Higgsfield (always this way)
1. `media_upload` with `filename` = the file's name — ONE file per call (several files in one call come back without names and the answer is too long to read).
2. Run exactly: `curl -s -o /dev/null -w '%{http_code}' -X PUT -H "Content-Type: <image/jpeg | video/mp4>" --data-binary @<path> '<upload_url>'` → must print 200.
3. `media_confirm` with `type` (`image` / `video`) and the `media_id`. One type per call: confirm videos and images in separate calls (several ids of the same type in one call is fine).
4. Save the id in `state/media.json` (keys listed in PRODUCT.md; `motion` for `motion/broll-motion.mp4`; characters/rooms under `"characters"` / `"rooms"` by file name) so you never upload the same file twice.
Generated images/videos can be used directly by their job id (no upload needed).

## Rules (all learned the hard way — follow every time)
1. **New person + new room for every video.** Get them with `python3 engine/tools.py next-set`, then LOOK at both photos. If one breaks the rules in the skill `find-sets` (face covered by a cup/phone, eyes closed, looking away, no Christmas tree, dark room…) → `python3 engine/tools.py reject <that file>` and run `next-set` again. If the pool is empty, run the skill `find-sets` (Pinterest search, then you pick the good ones). If that fails, ask the creator for ~20 high-quality photos of women and ~20 of cozy Christmas rooms in `library/characters/` and `library/rooms/`.
2. **The character photo is ALWAYS a direct reference** in every image and video where she appears (`image` role for images, `image_references` for videos).
3. **The robe is never designed from words.** Always attach the robe reference images listed in PRODUCT.md; the prompt says "reproduced one to one". The foot pocket/pouch images are ALWAYS attached in the B-roll.
4. **Top quality, always the same settings.** Video: only Kling 4.0 (`kling4_0`), `resolution: "1080p"`, `aspect_ratio: "9:16"` (never 720p). Images: only `nano_banana_pro`, `aspect_ratio: "9:16"`, `resolution: "4k"`, all refs with role `image_references` (never `nano_banana_2`, it is the weak one; never leave out aspect_ratio/resolution — you get 16:9 / low res).
4b. **Quality blocks in EVERY prompt.** Paste at the end of every image AND video prompt, word for word: `prompts/blocks/look.txt` (bright everyday UGC, shot on an iPhone 17 Pro Max) + `prompts/blocks/light.txt` (very soft natural light) + `prompts/blocks/no-text.txt`; in every VIDEO prompt also `prompts/blocks/motion.txt`. Never shorten them to save words — they are what makes it look real.
5. If a generate call answers "Preset X was recommended instead", call it again with `declined_preset_id` = the id it gives you.
6. **Check and repair everything yourself — skill `check`.** Run it after every image, every clip and on the final video, before telling the creator anything. The creator must never be the one who finds a mistake. Look at EVERY result before using it: `sheet` for videos, Read for images. Check face = character photo, robe = refs (hood, colours, pouch), hands, nothing strange, no text. Bad → generate again with the fix in the prompt (max 3 tries, then tell the creator).
7. **Always trim Kling clips**: `safe-end` + look at a 10 fps sheet of the last second (`sheet <clip> <out> 10` on a cut piece, or 4 fps on the whole clip); cut before any jump to a white product photo / the character photo / another picture / a sudden zoom / a fade, and before anything starts to melt or morph. safe-end only finds hard cuts — your eyes decide.
7b. **The person is ALWAYS in the foreground** — never behind a table, plant, sofa or any object. Write it in every image/video prompt: `she stands in the FOREGROUND, closest to the camera, with NOTHING between her and the camera; furniture is behind her or to the side`. If a result shows her behind something → redo. If the room photo has a table/plant/chair in the middle of the floor, FIRST make a version of the room without it (`nano_banana_pro`, 9:16, 4k, room photo as `image_references`: `Edit Image 1: keep the exact same room, angle and light. Change only: remove the <table> completely so the floor in front is open and empty. No text anywhere.`) and use that room photo for the hook — Kling ignores the prompt when the table is in the photo.
8. Lighting always very soft and natural, UGC iPhone look, no HDR/glow/CGI. Never ask for snow/dust blowing in the wind.
9. On-screen text: English, 2–3 short lines (`\n`), `"size": 76`, `"y": 0.08` (top), emojis like the reference. NEVER over a face or over the remote lights: check every segment on the sheet; where her face is at the top of the frame (B-roll), give that segment its own text entry with `"y": 0.42` (same words), so the text sits on her body, not her face.
9b. **Logos stay.** Logos, store signs and brands that are in the reference stay exactly as they are — never remove or blur them. Their on-screen text added on top of the video is removed with a clean photo (`tools.py cleantext`, HOOKS.md step 2), NEVER with blur — Kling copies blur patches.
10. Status `nsfw` (refunded, costs nothing) on a B-roll = character photo showing legs + motion clip, or prompt mentioning legs/feet/shorts → crop the character photo to head + shoulders (`tools.py crop`), long pajama pants, the short prompt and the fallback steps in `products/princess/PRODUCT.md`. `ip_detected` → try once more with the same refs; if it repeats, tell the creator.
11. `jobs_wait` returns errors like 502 sometimes → just call it again. If Higgsfield tools disappear, tell the creator to type `/mcp`, pick higgsfield and log in again.
13. **Budget: max 50–60 credits per finished video** (retries included). Plan before generating: hook by video-edit ≈ 3–5, start frame 11 each (avoid when video-edit can copy the shot), B-roll 7–8, connector 4 + remote 3, hook voice = write the line in the Kling hook prompt (`Sound: … says "…"`, free) — Seedance only if that voice is bad. Before every generation add up what this video already spent (`balance` before/after); at 45 stop adding extras (no extra variants, reuse fixed clips) and only finish what's missing. Never pass 60 without asking the creator.
12. Credits: check `balance` before starting. Real prices: Kling 4.0 video = 1 credit per second (B-roll 7 s = 7, hook clip 3 s = 3), Nano Banana Pro 4k = 4 per image. One full video ≈ 30–40 credits (princess p3: 30), max 50–60 with redos. Refused jobs (nsfw) are refunded. Under 80 credits → warn the creator first.

## Room check — sofa or bed (do it for EVERY room, before the B-roll)
LOOK at the room photo and write down: is there a **sofa**? a **bed**? both? floor space to stand?
- **Sofa in the room** → any motion clip works; in the prompt say the cozy/lying shot is "on its sofa".
- **Only a bed (bedroom)** → in the prompt say the cozy/lying shot is "on its bed". If the B-roll's last shot still looks wrong (sitting on nothing, floating, wrong furniture), cut the B-roll before it and make a separate **cozy bed shot**: start frame (nano_banana_pro, 9:16, 4k: the woman of the character photo in the robe, refs front+back, in this room next to the bed) → Kling image-to-video 5 s: she lets herself fall back onto the bed and wraps the robe around herself, cozy, face visible, real gravity, no floating. Check the fall on a 10 fps sheet; if it floats, use the version where she sits down on the edge and lies back.
- **Neither** (no sofa, no bed) → reject the room (`tools.py reject`) and take the next one.
Use the same room for the hook (if it's at home), the connector, the remote and the cozy shot, so the whole video happens in one place.

## Custom cozy — the creator chooses the last shot (variety)
The creator can ask for a different last cozy shot, e.g. `cozy: reading a book on the bed`, `cozy: drinking hot cocoa on the sofa`, `cozy: watching TV under the hood`. Then:
1. Cut the B-roll BEFORE its cozy shot (the cozy-zoom is not used).
2. Start frame: `nano_banana_pro`, 9:16, 4k, medias = character photo, room photo, robe front + back (+ hood/detail refs from PRODUCT.md): `A real candid iPhone photo in the room of Image 2, same light and furniture: the woman of Image 1 (same face) wears the robe of Images 3–4, reproduced one to one, hood <up / down as the robe is worn in PRODUCT.md> and <the action, e.g. lies on the bed propped on pillows reading an open paperback book, relaxed and cozy>. Her whole face is visible, she is in the foreground, nothing in front of her. Correct hands with five fingers, real objects with real size. Very soft natural light, true colours, UGC style. No text, no logos, no titles on the book.` Run `check` on it.
3. Kling `image-to-video`, `kling4_0`, 1080p, 9:16, `duration: 5`, start frame as `start_image`: `One continuous real handheld phone video starting exactly on the start image, no cuts, no zoom. <the action, slow and calm, e.g. she turns a page slowly and smiles, snuggles deeper into the robe>. The robe stays exactly as in the start image. Natural real movements with real weight, no morphing. Very soft natural light. Silent.` Use 2–2.5 s of it as the last shot (check the end, trim before anything strange).
4. Cost ≈ one image + one 5 s Kling clip — still inside the 50–60 credit budget. Log it: `cozy="<action>"` in `tools.py log`, and don't repeat the same cozy action in 3 videos in a row.
If the creator asks nothing, keep the free cozy from the B-roll.

## Delivery
Final file: `output/<name>/<name>-FINAL.mp4`. Also write `output/<name>/caption.txt` (one English sentence + 5 hashtags). Only after the skill `check` passed on the final video. Tell the creator in 3–5 lines: what the hook is, who/where, what the text says, a "Checked:" line (what you verified + what you fixed alone), anything you could not make perfect. Then open the folder for them if possible (Mac: `open output/<name>`, Windows: `explorer output\<name>`).
**Cloud (claude.ai/code) only**: the creator downloads from GitHub, so after every video run `git add -f output/<name>/<name>-FINAL.mp4 output/<name>/caption.txt && git commit -m "video <name>" && git push` (only the final file + caption, not the work files). If the folder is not a git repo (`git status` fails), you are on a computer, not the cloud — skip this.
