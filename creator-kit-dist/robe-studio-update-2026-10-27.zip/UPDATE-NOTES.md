# Robe Studio update 2026-10-27

- The hook now always gets the same spoken words as the original, on the same seconds (automatic check).
- Setup: the kit can install itself from one small file.
